/*
 * gpio_custom.h
 *
 *  Created on: Oct 7, 2024
 *      Authors: Horia-Petru Nazarie 100477735
 *				Rodrigo Dúran Morenilla 100480834
 */


#ifndef INC_GPIO_CUSTOM_H_
#define INC_GPIO_CUSTOM_H_



#endif /* INC_GPIO_CUSTOM_H_ */

#include <inttypes.h>
#include <stdbool.h>

#include "stm32l152xe.h"


#define FREQ 32000000

/* GPIO API START -----------------------------------------------------------------*/

// Selects a port based on a letter
GPIO_TypeDef* gpio_get_port_address(char port_letter){
	GPIO_TypeDef* target_port;

	switch(port_letter){
	case 'A': target_port = GPIOA; break;
	case 'B': target_port = GPIOB; break;
	case 'C': target_port = GPIOC; break;
	case 'D': target_port = GPIOD; break;
	case 'E': target_port = GPIOE; break;
	case 'F': target_port = GPIOF; break;
	case 'G': target_port = GPIOG; break;
	case 'H': target_port = GPIOH; break;
	}

	return target_port;
}

// Modifies MODER Register
enum { INPUT, OUTPUT, AF, ANALOG };
void gpio_set_mode(char port, uint8_t num, uint8_t mode){
	GPIO_TypeDef* target_gpiox = gpio_get_port_address(port);

	target_gpiox->MODER &= ~(0x00000003 << (num * 2));	// Resetting the values
	target_gpiox->MODER |= (mode <<(num * 2));			// Set the pin mode
}

enum { AFIO0, AFIO1, AFIO2, AFIO3, AFIO4, AFIO5, AFIO6, AFIO7, AFIO8, AFIO9, AFIO10, AFIO11, AFIO12, AFIO13, AFIO14, AFIO15 };
void gpio_set_af(char port, uint8_t num, uint8_t afio_num){
	GPIO_TypeDef* target_gpiox = gpio_get_port_address(port);

	target_gpiox->AFR[num / 8] &= ~(0x00000004 << ((num % 8) * 4));
	target_gpiox->AFR[num / 8] |= (afio_num << ((num % 8) * 4));
}

// Modifies OTYPER Register
enum { OUTPUT_TYPE_PP, OUTPUT_TYPE_OD };
void gpio_set_output_type(char port, uint8_t num, uint8_t type){
	GPIO_TypeDef* target_gpiox = gpio_get_port_address(port);

	target_gpiox->OTYPER &= ~(0x00000001 << num);	// Resetting the values
	target_gpiox->OTYPER |= (type << num);			// Set the pin type
}

// Modifies PUPDR Register
enum { NOPULL, PULLUP, PULLDOWN };
void gpio_set_pupd(char port, uint8_t num, uint8_t resistor){
	GPIO_TypeDef* target_gpiox = gpio_get_port_address(port);

	target_gpiox->PUPDR &= ~(0x00000001 << (num * 2));	// Resetting the values
	target_gpiox->PUPDR |= (resistor << (num * 2));		// Set the pin type
}

// Modifies BSRR Register
enum { OFF, ON };
void gpio_bit_set_reset(char port, uint8_t num, bool set){
	GPIO_TypeDef* target_gpiox = gpio_get_port_address(port);

	target_gpiox->BSRR = (0x00000001 << num) << (set ? 0 : 16);
}

// Reads from IDR Register
char gpio_read_input(char port, uint8_t num){
	GPIO_TypeDef* target_gpiox = gpio_get_port_address(port);

	return (target_gpiox->IDR & (0x00000001 << num)) ? 1 : 0;
}

/* GPIO API END -----------------------------------------------------------------*/

/* EXTI API START -----------------------------------------------------------------*/


//	Initializes and associates the EXTI external interupt to a port and pin
// *** The pin has to be already in input mode ***
enum { FallingEdge, RaisingEdge, BothEdges };
void exti_init(char port, uint8_t pin_num, uint8_t edge){
	RCC->APB2ENR |= (0x00000001 << 0);		// Enable SYSCFG Clock

	uint8_t exti_reg = pin_num / 4;			// The EXTI register
	uint8_t exti_pin = pin_num % 4;			// The EXTI pin's first bit
	uint8_t exti_port = port - 'A';			// The EXTI port to set
	SYSCFG->EXTICR[exti_reg] &= ~(0x0000000F << (exti_pin * 4));	// Resetting the values
	SYSCFG->EXTICR[exti_reg] |= (exti_port << (exti_pin * 4));		// Configure port on EXTI line exti_pin

	EXTI->IMR |= (0x00000001 << pin_num);	// Unmask EXTI interrupt on line exti_pin

	// Edge trigger selection
	if(edge == RaisingEdge){
		EXTI->RTSR |= (0x00000001 << pin_num);
		EXTI->FTSR &= ~(0x00000001 << pin_num);
	}
	else if(edge == FallingEdge){
		EXTI->RTSR &= ~(0x00000001 << pin_num);
		EXTI->FTSR |= (0x00000001 << pin_num);
	}

	//	Enable NVIC Interrupt
	if(pin_num == 0){
		NVIC_EnableIRQ(EXTI0_IRQn);
	}
	else if(pin_num == 1){
		NVIC_EnableIRQ(EXTI1_IRQn);
	}
	else if(pin_num == 2){
		NVIC_EnableIRQ(EXTI2_IRQn);
	}
	else if(pin_num == 3){
		NVIC_EnableIRQ(EXTI3_IRQn);
	}
	else if(pin_num == 4){
		NVIC_EnableIRQ(EXTI4_IRQn);
	}
	else if(pin_num < 10){
		NVIC_EnableIRQ(EXTI9_5_IRQn);
	}
	else{
		NVIC_EnableIRQ(EXTI15_10_IRQn);
	}

}

/* EXTI API END -----------------------------------------------------------------*/

/* TIMER API START -----------------------------------------------------------------*/

// Selects the timer based on its number
enum { T2=2, T3, T4, T5, T6, T7, T9=9, T10, T11 };
TIM_TypeDef *get_timer(uint8_t timer){
	TIM_TypeDef* tim;

	switch(timer){
	case 2: tim = TIM2; break;
	case 3: tim = TIM3; break;
	case 4: tim = TIM4; break;
	case 5: tim = TIM5; break;
	case 6: tim = TIM6; break;
	case 7: tim = TIM7; break;
	case 9: tim = TIM9; break;
	case 10: tim = TIM10; break;
	case 11: tim = TIM11; break;
	}

	return tim;
}

void channel_irq_timer_init(TIM_TypeDef *tim, char channel){
	channel = channel - '0';
	tim->DIER |= (0x00000001 << channel);
}


void timer_irq_init(uint8_t timer, char *channel_irq){
	TIM_TypeDef *tim = get_timer(timer);

	char *channel = channel_irq;
	while(*channel != '\0'){
		channel_irq_timer_init(tim, *channel);
		channel++;
}

	//	Enable NVIC Interrupt
	switch(timer){
	case 2: NVIC_EnableIRQ(TIM2_IRQn);break;
	case 3: NVIC_EnableIRQ(TIM3_IRQn);break;
	case 4: NVIC_EnableIRQ(TIM4_IRQn);break;
	case 5: NVIC_EnableIRQ(TIM5_IRQn);break;
	case 6: NVIC_EnableIRQ(TIM6_IRQn);break;
	case 7: NVIC_EnableIRQ(TIM7_IRQn);break;
	case 9: NVIC_EnableIRQ(TIM9_IRQn);break;
	case 10: NVIC_EnableIRQ(TIM10_IRQn);break;
	case 11: NVIC_EnableIRQ(TIM11_IRQn);break;
	}
}

// Set up timer for 1us time unit
void timer_enable_microseconds(uint8_t timer){
	TIM_TypeDef* tim = get_timer(timer);

	if(!(tim->CR1 & (0x00000001 << 0))){

		// Enable BUS Clock
		if(timer < 8){
			RCC->APB1ENR |= (0x00000001 << (timer - 2));
		}
		else{
			RCC->APB2ENR |= (0x00000001 << (timer - 7));
		}

		// Configure timer
		tim->PSC = (32-1);
	}
	tim->CNT = 0;
}

// Set up timer for 1ms time unit
void timer_enable_miliseconds(uint8_t timer){
	TIM_TypeDef* tim = get_timer(timer);

	if(!(tim->CR1 & (0x00000001 << 0))){

		// Enable BUS Clock
		if(timer < 8){
			RCC->APB1ENR |= (0x00000001 << (timer - 2));
		}
		else{
			RCC->APB2ENR |= (0x00000001 << (timer - 7));
		}

		// Configure timer
		tim->PSC = (32000-1);
	}
	tim->CNT = 0;

}

// Starts the timer
void start_timer(uint8_t timer){
	TIM_TypeDef* tim = get_timer(timer);

	tim->CR1 |= (0x00000001 << 0);
}

void stop_timer(uint8_t timer){
	TIM_TypeDef* tim = get_timer(timer);
	if(tim->CR1 & (0x00000001 << 0)){
		tim->CR1 &= ~(0x00000001 << 0);	// Stop timer
	}
}

void update_timer(uint8_t timer, uint16_t compare_value, uint8_t channel, uint32_t arr){
	TIM_TypeDef* tim = get_timer(timer);

	tim->CR1 &= ~(0x00000001 << 0);			// Disable Timer

	switch(arr){
	case 0: break;
	default:
		tim->ARR = (arr - 1); break;
	}

	switch(channel){
	case 0: break;
	case 1: tim->CCR1 = (compare_value - 1); break;
	case 2: tim->CCR2 = (compare_value - 1); break;
	case 3: tim->CCR3 = (compare_value - 1); break;
	case 4: tim->CCR4 = (compare_value - 1); break;
	}

	tim->EGR |= (0x00000001 << 0);                 // Generate update event
	tim->SR = 0;
	start_timer(timer);
}

enum { Frozen, Active, Inactive, Toggle, Force_Low, Force_High, PWM1, PWM2 };
void update_timer_mode(uint8_t timer, uint8_t channel, uint8_t mode){
	TIM_TypeDef* tim = get_timer(timer);

	tim->CR1 &= ~(0x00000001 << 0);					// Disable Timer
	switch(channel){
	case 1:
		tim->CCMR1 &= ~(0x00000007 << 4);
		tim->CCMR1 |= (mode << 4);
		break;
	case 2:
		tim->CCMR1 &= ~(0x00000007 << 12);
		tim->CCMR1 |= (mode << 12);
		break;
	case 3:
		tim->CCMR2 &= ~(0x00000007 << 4);
		tim->CCMR2 |= (mode << 4);
		break;
	case 4:
		tim->CCMR2 &= ~(0x00000007 << 12);
		tim->CCMR2 |= (mode << 12);
		break;
	}

	tim->EGR |= (0x00000001 << 0);                 // Generate update event
	tim->SR = 0;
	start_timer(timer);
}

// Starts the timer (with IRQ) and counts to ms value
void start_timer_irq(uint8_t timer, uint32_t ms){

	timer_enable_miliseconds(timer);

	timer_irq_init(timer, "0");

	update_timer(timer, 0, 0, ms);
}

// Compare (output) timer toggle
enum { channel1=1, channel2, channel3, channel4 };
enum { ms, us }; // miliseconds or microseconds
void timer_compare_init(uint8_t timer, uint8_t channel, uint8_t time_unit, uint16_t compare_value, uint32_t arr){
	TIM_TypeDef* tim = get_timer(timer);

	switch(time_unit){
	case ms: timer_enable_miliseconds(timer); break;
	case us: timer_enable_microseconds(timer);break;
	}

	tim->ARR = (arr-1);				// Set time period

	// Set channel mode to compare (submode 'toggle') & compare value
	switch(channel){
	case 1:
		tim->CCMR1 &= ~(0x00000007 << 4);
		tim->CCMR1 |= (0x00000003 << 4);
		tim->CCR1 = (compare_value - 1);
		break;
	case 2:
		tim->CCMR1 &= ~(0x00000007 << 12);
		tim->CCMR1 |= (0x00000003 << 12);
		tim->CCR2 = (compare_value - 1);
		break;
	case 3:
		tim->CCMR2 &= ~(0x00000007 << 4);
		tim->CCMR2 |= (0x00000003 << 4);
		tim->CCR3 = (compare_value - 1);
		break;
	case 4:
		tim->CCMR2 &= ~(0x00000007 << 12);
		tim->CCMR2 |= (0x00000003 << 12);
		tim->CCR4 = (compare_value - 1);
		break;
	}

	tim->CCER |= (0x00000001 << (channel - 1) * 4);	// Enable compare
}

// Compare (output) timer PWM
void timer_pwm_init(uint8_t timer, uint8_t channel, uint8_t time_unit, uint16_t compare_value, uint32_t arr){
	TIM_TypeDef* tim = get_timer(timer);

	// Reset the timer
	tim->CR1 = 0;
	tim->CR2 = 0;
	tim->SMCR = 0;

	switch(time_unit){
		case ms: timer_enable_miliseconds(timer); break;
		case us: timer_enable_microseconds(timer);break;
	}

	tim->ARR = (arr-1);				// Set time period

	// Set compare value & channel mode to output (submode 'PWM')
	switch(channel){
	case 1:
		tim->CCMR1 &= ~(0x00000007 << 4);
		tim->CCMR1 |= (0x00000006 << 4);
		tim->CCR1 = (compare_value - 1);
		break;
	case 2:
		tim->CCMR1 &= ~(0x00000007 << 12);
		tim->CCMR1 |= (0x00000006 << 12);
		tim->CCR2 = (compare_value - 1);
		break;
	case 3:
		tim->CCMR2 &= ~(0x00000007 << 4);
		tim->CCMR2 |= (0x00000006 << 4);
		tim->CCR3 = (compare_value - 1);
		break;
	case 4:
		tim->CCMR2 &= ~(0x00000007 << 12);
		tim->CCMR2 |= (0x00000006 << 12);
		tim->CCR4 = (compare_value - 1);
		break;
	}

	tim->CCER |= (0x00000001 << (channel - 1) * 4);	// Enable compare
}

// Capture input timer
void timer_capture_init(uint8_t timer, uint8_t channel, uint8_t edge, char *channel_irq, uint32_t arr){
	TIM_TypeDef* tim = get_timer(timer);

	timer_enable_microseconds(timer);

	// Enable interrupts
	timer_irq_init(timer, channel_irq);

	tim->ARR = (arr-1);				// Set time period

	// Set channel mode to input (capture)
	switch(channel){
	case 1:
		tim->CCMR1 &= ~(0x00000002 << 0);
		tim->CCMR1 |= (0x00000001 << 0);
		break;
	case 2:
		tim->CCMR1 &= ~(0x00000002 << 8);
		tim->CCMR1 |= (0x00000001 << 8);
		break;
	case 3:
		tim->CCMR2 &= ~(0x00000002 << 0);
		tim->CCMR2 |= (0x00000001 << 0);
		break;
	case 4:
		tim->CCMR2 &= ~(0x00000002 << 8);
		tim->CCMR2 |= (0x00000001 << 8);
		break;
	}

	// Set edge detection
	switch(edge){
	case RaisingEdge:
		tim->CCER &= ~(0x00000001 << (((channel - 1) * 4) + 1));
		tim->CCER &= ~(0x00000001 << (((channel - 1) * 4) + 3));
		break;
	case FallingEdge:
		tim->CCER &= ~(0x00000001 << (((channel - 1) * 4) + 1));
		tim->CCER &= ~(0x00000001 << (((channel - 1) * 4) + 3));
		tim->CCER |= (0x00000001 << (((channel - 1) * 4) + 1));
		break;
	case BothEdges:
		tim->CCER &= ~(0x00000001 << (((channel - 1) * 4) + 1));
		tim->CCER &= ~(0x00000001 << (((channel - 1) * 4) + 3));
		tim->CCER |= (0x00000001 << (((channel - 1) * 4) + 1));
		tim->CCER |= (0x00000001 << (((channel - 1) * 4) + 3));
		break;
	}

	tim->CCER |= (0x00000001 << (channel - 1) * 4);	// Enable capture
}

uint16_t timer_capture_get_value(uint8_t timer, uint8_t channel){
	TIM_TypeDef* tim = get_timer(timer);

	switch(channel){
	case 1: return tim->CCR1;
	case 2: return tim->CCR2;
	case 3: return tim->CCR3;
	case 4: return tim->CCR4;
	}
	return 0;
}



/* TIMER API END -----------------------------------------------------------------*/

/* ADC API START -----------------------------------------------------------------*/

void adc_init_single_ch_cont(uint8_t channel){
	RCC->APB2ENR |= (0x00000001 << 9);				// Clock the ADC

	ADC1->CR1 |= (0x00000001 << 5);					// Enable end of conversion interrupt
	NVIC_EnableIRQ(ADC1_IRQn);						// Enable hardware interrupt
	NVIC_SetPriority(ADC1_IRQn, 4);					// ADC priority below the timers

	ADC1->SQR5 |= (channel << 0);					// Single Channel
	ADC1->CR2 |= (0x00000001 << 0);					// Wake up ADC
	ADC1->CR2 |= (0x00000001 << 1);					// Continuous mode
	while((ADC1->SR & (0x00000001 << 6)) == 0){}	// Wait for ADONS bit (ADC is ready to convert)

	ADC1->CR2 |= (0x00000001 << 30);				// Start ADC conversion
}

/* ADC API END -----------------------------------------------------------------*/

/* UART API START -----------------------------------------------------------------*/

void usart_init(USART_TypeDef *usart, uint64_t baud){
	if(usart == USART1){
		RCC->APB2ENR |= (0x00000001 << 14);	// Enable clock
		gpio_set_mode('A', 9, AF);			// Set Tx
		gpio_set_af('A', 9, AFIO7);
		gpio_set_mode('A', 10, AF);			// Set Rx
		gpio_set_af('A', 10, AFIO7);
		NVIC_EnableIRQ(USART1_IRQn);
	}
	else if(usart == USART2){
		RCC->APB1ENR |= (0x00000001 << 17);
		gpio_set_mode('A', 2, AF);
		gpio_set_af('A', 2, AFIO7);
		gpio_set_mode('A', 3, AF);
		gpio_set_af('A', 3, AFIO7);
		NVIC_EnableIRQ(USART2_IRQn);
	}
	else if(usart == USART3){
		RCC->APB1ENR |= (0x00000001 << 18);
		gpio_set_mode('B', 10, AF);
		gpio_set_af('B', 10, AFIO7);
		gpio_set_mode('B', 11, AF);
		gpio_set_af('B', 11, AFIO7);
		NVIC_EnableIRQ(USART3_IRQn);
	}
	usart->BRR = FREQ / baud;
	usart->CR1 |= (0x00000001 << 5);					// Interrupt RxNE
//	usart->CR1 |= (0x00000001 << 6);					// Interrupt TC
//	usart->CR1 |= (0x00000001 << 7);					// Interrupt TxE

	usart->CR1 |= (0x00000001 << 2);					// Enable RE
	usart->CR1 |= (0x00000001 << 3);					// Enable TE
	usart->CR1 |= (0x00000001 << 13);					// Enable UART
}



/* UART API END -----------------------------------------------------------------*/

/* Robot Car API START -----------------------------------------------------------------*/


void rear_sensor_enable(void){
	start_timer_irq(T6, 250);								// TIM6 Base time
	start_timer(T4);										// Echo detection
	start_timer(T9);										// Buzzer
}

void rear_sensor_diable(void){
	update_timer_mode(T9, channel2, Force_Low);
	stop_timer(T6);
	stop_timer(T4);
	stop_timer(T9);
}

void buzzer_init(void){
	gpio_set_mode('B', 14, AF);								// Set PB14 to Alternate Function
	gpio_set_af('B', 14, AFIO3);							// PB14->AF = AFIO3 (TIM9_CH2)
	gpio_set_output_type('B', 14, OUTPUT_TYPE_PP);			// Set Output type Push-Pull
	timer_compare_init(T9, channel2, ms, 250, 500);		// TIM9_CH2 Compare TOC Toggle
}

void ultrasonic_init(void){
	// Trigger
	gpio_set_mode('A', 7, AF);								// Set PA7 to Alternate Function
	gpio_set_af('A', 7, AFIO3);								// PA7->AF = AFIO3 (TIM11_CH1)
	timer_compare_init(T11, channel1, us, 10, 20);			// TIM11_CH1 Compare TOC One-Pulse mode
	TIM11->CR1 |= (1 << 3);									// Set One-Pulse mode

	// Echo
	gpio_set_mode('B', 6, AF);								// Set PB6 to Alternate Function
	gpio_set_af('B', 6, AFIO2);								// PB6->AF = AFIO2 (TIM4_CH1)
	timer_capture_init(T4, channel1, BothEdges, "1", 61000);// TIM4_CH1 Capture TIC BothEdges
}

void bluetooth_module_init(void){
	usart_init(USART1, 9600);
}

void setup_wheels(){
	/* Left Wheels */
	gpio_set_mode('A', 1, OUTPUT);
	gpio_set_output_type('A', 1, OUTPUT_TYPE_PP);
	gpio_bit_set_reset('A', 1, OFF);

	gpio_set_mode('A', 4, OUTPUT);
	gpio_set_output_type('A', 4, OUTPUT_TYPE_PP);
	gpio_bit_set_reset('A', 4, OFF);

	gpio_set_mode('A', 0, AF);
	gpio_set_af('A', 0, AFIO1);
	timer_pwm_init(T2, channel1, us, 2800, 3000);			// TIM2_CH1 controls left wheels speed

	/* Right Wheels */
	gpio_set_mode('B', 5, OUTPUT);
	gpio_set_output_type('B', 5, OUTPUT_TYPE_PP);
	gpio_bit_set_reset('B', 5, OFF);

	gpio_set_mode('B', 3, OUTPUT);
	gpio_set_output_type('B', 3, OUTPUT_TYPE_PP);
	gpio_bit_set_reset('B', 3, OFF);

	gpio_set_mode('B', 10, AF);
	gpio_set_af('B', 10, AFIO1);
	timer_pwm_init(T2, channel3, us, 2800, 3000);			// TIM3_CH1 controls right wheels speed
}

enum { Stop, Forward, Backwards, Turn_Right, Turn_Left };
void right_wheels(uint8_t direction){
	switch(direction){
	case Stop:
		gpio_bit_set_reset('B', 5, OFF);
		gpio_bit_set_reset('B', 3, OFF);
		break;
	case Forward:
		gpio_bit_set_reset('B', 5, OFF);
		gpio_bit_set_reset('B', 3, ON);
		break;
	case Backwards:
		gpio_bit_set_reset('B', 5, ON);
		gpio_bit_set_reset('B', 3, OFF);
		break;
	}
}

void left_wheels(uint8_t direction){
	switch(direction){
	case Stop:
		gpio_bit_set_reset('A', 1, OFF);
		gpio_bit_set_reset('A', 4, OFF);
		break;
	case Forward:
		gpio_bit_set_reset('A', 1, ON);
		gpio_bit_set_reset('A', 4, OFF);
		break;
	case Backwards:
		gpio_bit_set_reset('A', 1, OFF);
		gpio_bit_set_reset('A', 4, ON);
		break;
	}
}

void drive(uint8_t direction){
	switch(direction){
	case Turn_Right:
		left_wheels(Forward);
		right_wheels(Backwards);
		break;
	case Turn_Left:
		left_wheels(Backwards);
		right_wheels(Forward);
		break;
	default:
		left_wheels(direction);
		right_wheels(direction);
		break;
	}
}

enum {	stop, low, medium, high };
void set_speed(uint8_t speed){
	switch(speed){
	case high:		// Set speed 93.33%
		update_timer(T2, 2800, channel1, 0);
		update_timer(T2, 2800, channel3, 0);
		break;
	case medium:	// Set speed 75%
		update_timer(T2, 2250, channel1, 0);
	 	update_timer(T2, 2250, channel3, 0);
	 	break;
	case low:		// Set speed 50%
		update_timer(T2, 1500, channel1, 0);
		update_timer(T2, 1500, channel3, 0);
		break;
	case stop:
		update_timer(T2, 1, channel1, 0);
		update_timer(T2, 1, channel3, 0);
		break;
	}
}

void rear_sensor(void){
	extern uint16_t distance;
	start_timer(T11);
	if(distance < 10){
		update_timer_mode(T9, channel2, Force_High);
		set_speed(stop);
	}
	else if((distance >= 10) && (distance < 50)){
		update_timer_mode(T9, channel2, Toggle);
		set_speed(low);
	}
	else{
		update_timer_mode(T9, channel2, Force_Low);
		set_speed(high);
	}
}

int msb(int v){
	unsigned int r = 0;
	while (v >>= 1) {
		r++;
	}
	return r;
}

double ln(float y) {
    int log2;
    float divisor, x, result;

    log2 = msb((int)y);
    divisor = (float)(1 << log2);
    x = y / divisor;    // normalized value between [1.0, 2.0]

    result = -1.7417939 + (2.8212026 + (-1.4699568 + (0.44717955 - 0.056570851 * x) * x) * x) * x;
    result += ((float)log2) * 0.69314718; // ln(2) = 0.69314718

    return result;
}

void send_temperature(uint16_t temperature){
	int a_reverse = 0;
	while(temperature != 0){
		a_reverse *= 10;
		a_reverse += temperature % 10;
		temperature /= 10;
	}
	char c;
	while(a_reverse != 0){
		c = (a_reverse%10) + '0';
		while(!(USART1->SR & (0x00000001 << 6))){}
		USART1->DR = c;
		while(!(USART1->SR & (0x00000001 << 7))){}
		a_reverse /= 10;
	}
}

/* Robot Car API END -----------------------------------------------------------------*/
